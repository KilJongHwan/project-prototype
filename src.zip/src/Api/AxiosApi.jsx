import axios from "axios";
const DOMAIN = "http://localhost:8111";

const AxiosApi = {
  // 로그인
  memberLogin: async (id, pw) => {
    const login = {
      id: id,
      pwd: pw,
    };
    return await axios.post(DOMAIN + "/users/login", login);
  },
  memberSignup: async (id, pw, email, phone) => {
    const signupData = {
      id: id,
      pwd: pw,
      email: email,
      phone: phone,
    };
    return await axios.post(DOMAIN + "/users/signup", signupData);
  },
};

export default AxiosApi;
