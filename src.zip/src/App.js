import "./App.css";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import BuyReviewPg from "./pages/BuyReviewPg";
import LoginComponent from "./pages/Login";

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<LoginComponent />} />
        <Route path="/purchase" element={<BuyReviewPg />} />
      </Routes>
    </Router>
  );
}

export default App;
