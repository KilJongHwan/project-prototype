import React, { useState, useEffect } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faFacebook } from "@fortawesome/free-brands-svg-icons";
import KakaoColorImg from "../images/kakao_color.png";
import KakaoImg from "../images/kakao_white.png";
import {
  Wrapper,
  Container,
  Form,
  Input,
  Button,
  SocialLinks,
  SocialLink,
  OverlayButton,
  OverlayLeft,
  OverlayRight,
  ErrorText,
} from "../components/LoginStyle";
import AxiosApi from "../Api/AxiosApi";
import { Navigate } from "react-router-dom";

const LoginComponent = () => {
  const [socialImage, setSocialImage] = useState(KakaoColorImg); // 초기 이미지 설정

  const socialHover = () => {
    setSocialImage(KakaoColorImg);
  };

  const socialLeave = () => {
    setSocialImage(KakaoImg);
  };

  const [isRightPanelActive, setIsRightPanelActive] = useState(false);
  const [inputId, setInputId] = useState("");
  const [inputPw, setInputPwd] = useState("");

  const toggleRightPanel = () => {
    setIsRightPanelActive(!isRightPanelActive);
  };
  const [signUpData, setSignUpData] = useState({
    username: "",
    password: "",
    email: "",
    phone: "",
  });

  const [dataErrors, setDataErrors] = useState({
    username: "",
    password: "",
    email: "",
    phone: "",
  });

  const [isSubmitDisabled, setIsSubmitDisabled] = useState(true);

  useEffect(() => {
    const validateForm = () => {
      const usernameRegex = /^[a-zA-Z0-9]{8,20}$/;
      const passwordRegex =
        /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,20}$/;
      const emailRegex = /^[A-Za-z0-9]+@[A-Za-z]+\.[A-Za-z]+$/;
      const phoneRegex = /^\d{2,3}-\d{3,4}-\d{4}$/;

      const usernameError = !usernameRegex.test(signUpData.username)
        ? "ID 8~20자의 영문 대소문자와 숫자 조합이어야 합니다."
        : "";

      const passwordError = !passwordRegex.test(signUpData.password)
        ? "Password 8~20자의 대소문자, 특수문자, 숫자를 포함해야 합니다."
        : "";

      const emailError = !emailRegex.test(signUpData.email)
        ? "올바른 이메일 형식이 아닙니다."
        : "";

      const phoneError = !phoneRegex.test(signUpData.phone)
        ? "올바른 전화번호 형식이 아닙니다."
        : "";

      setDataErrors({
        username: usernameError,
        password: passwordError,
        email: emailError,
        phone: phoneError,
      });
    };

    validateForm();

    setIsSubmitDisabled(
      dataErrors.username || dataErrors.password || dataErrors.email
    );
  }, [signUpData, dataErrors]);

  const textChange = (e) => {
    const { name, value } = e.target;
    setSignUpData({ ...signUpData, [name]: value });
  };

  const loginSubmit = async (e) => {
    e.preventDefault();
    const res = await AxiosApi.memberLogin(inputId, inputPw);
    console.log(res.data);
    if (res.data === true) {
      window.localStorage.setItem("userId", inputId); // 브라우저에서 임시로 값을 저장하는 기술
      window.localStorage.setItem("userPw", inputPw);
      window.localStorage.setItem("isLogin", "TRUE");
      Navigate("/purchase");
    } else {
    }
  };

  return (
    <Wrapper>
      <Container>
        <Form $isRightPanelActive={isRightPanelActive}>
          {!isRightPanelActive ? (
            <>
              <h1>Sign In</h1>
              <SocialLinks>
                <SocialLink>
                  <FontAwesomeIcon icon={faFacebook} />
                </SocialLink>
                <SocialLink>
                  <img
                    src={socialImage}
                    alt="cacao"
                    style={{ width: "100%", height: "100%" }}
                    onMouseEnter={socialHover}
                    onMouseLeave={socialLeave}
                  />
                </SocialLink>
                <SocialLink></SocialLink>
              </SocialLinks>
              <span>or use your account</span>
              <Input
                type="text"
                placeholder="ID"
                value={inputId}
                onChange={(e) => setInputId(e.target.value)}
              />
              <Input
                type="password"
                placeholder="Password"
                value={inputPw}
                onChange={(e) => setInputPwd(e.target.value)}
              />
              <Button className="form_btn" onClick={loginSubmit}>
                Sign In
              </Button>
            </>
          ) : (
            <>
              <h1>Create Account</h1>
              <Input
                type="text"
                name="username"
                placeholder="Name"
                value={signUpData.username}
                onChange={textChange}
              />
              {dataErrors.username && (
                <ErrorText>{dataErrors.username}</ErrorText>
              )}
              <Input
                type="password"
                name="password"
                placeholder="Password"
                value={signUpData.password}
                onChange={textChange}
              />
              {dataErrors.password && (
                <ErrorText>{dataErrors.password}</ErrorText>
              )}
              <Input
                type="email"
                name="email"
                placeholder="Email"
                value={signUpData.email}
                onChange={textChange}
              />
              {dataErrors.email && <ErrorText>{dataErrors.email}</ErrorText>}
              <Button disabled={isSubmitDisabled}>Sign Up</Button>
            </>
          )}
        </Form>
        {isRightPanelActive ? (
          <OverlayLeft $isRightPanelActive={isRightPanelActive}>
            <h1>Welcome Back</h1>
            <p>
              To keep connected with us, please login with your personal info
            </p>
            <OverlayButton onClick={toggleRightPanel}>Sign In</OverlayButton>
          </OverlayLeft>
        ) : (
          <OverlayRight $isRightPanelActive={isRightPanelActive}>
            <h1>Hello, Friend</h1>
            <p>Enter your personal details and start a journey with us</p>
            <OverlayButton onClick={toggleRightPanel}>Sign Up</OverlayButton>
          </OverlayRight>
        )}
      </Container>
    </Wrapper>
  );
};

export default LoginComponent;
